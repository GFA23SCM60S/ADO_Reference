
**Buffer Manager CS525 Advanced Database Organization Assignment No. 2**

----------------------------------------------------

***Authors***

Group 12 Spring 23

- Shlok Mohan Chaudhari         A20525610
- Shivdeep Bisurkar             A20525712
- Zeyu Liu                      A20481907

----------------------------------------------------

***Steps to test the buffer manager***

----------------------------------------------------

We have edited the tests in test file `test_assign2_1.c`. Following make command compiles, links and runs the tests in the test file seamlessly. Output of this command is an executable `test_assign2_1`.
```
$ make
```

To execute the tests for LRU and FIFO page replacement strategies. 
```
$ ./test_assign2_1
```

Please make sure to use the following command to cleanup any object files and output files before using above command to retest the storage manager.
```
$ make clean
```
----------------------------------------------------

***Functionalities***

----------------------------------------------------
****Page Replacement Strategy****

****Least-Recently-Used (LRU )page replacement strategy****
```
1.Least-Recently Used removes page frame that is not used in long time.
2.fixcnt is used to keep count of each page frame
3.So when buffer manager become full replace frame with least count and push changes to disk if page is dirty i.e. modified.
```

****First-In-First-Out page replacement strategy****
```
1.Check if there are empty spaces in buffer pool and first fill those frames 
2.If not, search first non used Frame.
3.Before replacing Frame check page is dirty, push changes to disk and add new page at that location.
```

-----------------------------------------------------------

****Buffer Pool Functions****

`initBufferPool()`: BufferPool initialization

`shutdownBufferPool()`:Destroy the buffer pool (shutdown a buffer pool and free up all associated resources)

`forceFlushPool()`:Flush All the pages to the disk whose dirtyBit is set

****Page Management Functions****

`markDirty()`:mark the page as dirty

`unpinPage()`: unpin page from buffer pool

`createPageFrame()`:Create a Buffer Pool with specified number of Page Frames

`forcePage()`:force a page back to disk

`pinPage()`: Add a page onto the buffer pool

****Statistics Functions****

`getFrameContents()`:Fetch array of PageNumbers (of size numPages) where ith element is the number of the page stored in the ith page frame.

`getDirtyFlags()`:Get array of bools (of size numPages) where ith element is TRUE if the page stored in the ith page frame is dirty.

`getFixCounts()`:Fetch array of integers (of size numPages) where ith element is the fix count of the page stored in the ith page frame.

`getNumReadIO()`:Get total number of readBlock operations

`getNumWriteIO()`:Fetch total number of writeBlock operations
