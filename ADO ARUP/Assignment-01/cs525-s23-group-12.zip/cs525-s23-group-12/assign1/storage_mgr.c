#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "dberror.h"
#include "storage_mgr.h"

FILE *fp;																	// Global file pointer

/*
	@brief Initialize Storage Manager
	@param void
	@return void
*/
void initStorageManager(void) {
	fp = NULL;
}

/*
	@brief Create a page file
	@param char *filename Name of the new file to be created
	@return RC Return Code
*/
RC createPageFile(char *fileName) {
	size_t size = PAGE_SIZE * sizeof(char);									// Creating size bytes of memory using PAGE_SIZE
	char *memBlock = malloc(size); 											// Declaring MemoryBlock with above size

	RC returncode = RC_FILE_NOT_FOUND;										// Setting Return Code to file NOT_FOUND by default

	fp = fopen(fileName, "w+"); 											// Opening file in write mode
	if (fp != 0) {															// Checking if file exists. Use file NOT_FOUND returncode if it doesn't
		memset(memBlock, '\0', PAGE_SIZE); 									// Using memset to set the allocated memory block by null
		fwrite(memBlock, sizeof(char), PAGE_SIZE, fp);						// Writing the allocated memory block to the file
		free(memBlock);														// Freeing the memoryBlock
		fclose(fp);															// Closing the file since it's now created
		returncode = RC_OK;													// Setting Return Code to OK
	}
	return returncode;														// Returning appropriate returncode
}

/*
	@brief Open a page file
	@param char* filename Name of the file to be opened
	@param SM_FileHandle *fHandle File handler representing an open page file
	@return RC Return Code
*/
RC openPageFile(char *fileName, SM_FileHandle *fHandle) {
	RC returncode = RC_FILE_NOT_FOUND;										// Setting Return Code to file NOT_FOUND by default

	fp = fopen(fileName, "r+");												// Opening file in read mode
	if (fp != 0) {															// Checking if file exists. Use file NOT_FOUND returncode if it doesn't
		fseek(fp, 0, SEEK_END);												// Pointing the file pointer to the last location of file
		int lastByte = ftell(fp); 											// Returning the last byte of file
		int totalNumPages = (lastByte + 1) / PAGE_SIZE; 					// Recording total number of pages in the file

		(*fHandle).totalNumPages = totalNumPages;							// Setting total number of pages
		(*fHandle).fileName = fileName; 									// Setting file name
		(*fHandle).curPagePos = 0;											// Setting current page position
		
		rewind(fp); 														// Setting the file pointer to the start of the file
		returncode = RC_OK;													// Setting Return Code to OK
	}
	return returncode;														// Returning appropriate returncode
}

/*
	@brief Close a page file
	@param SM_FileHandle *fHandle File handler representing an open page file
	@return RC Return Code
*/
RC closePageFile(SM_FileHandle *fHandle) {
	RC isFileClosed = fclose(fp);											// Closing the file
	
	RC returncode = RC_FILE_NOT_FOUND;										// Setting Return Code to file NOT_FOUND by default
	if (isFileClosed == 0)													// Checking if file is closed
		returncode = RC_OK;													// Setting Return Code to OK by default if file is closed
	
	return returncode;														// Returning appropriate returncode
}

/*
	@brief Destroy or remove a page file
	@param char *filename Name of the file to be removed
	@return RC Return Code
*/
RC destroyPageFile(char *fileName) {
	int status = remove(fileName);											// Removing the page file

	RC returncode = RC_FILE_NOT_FOUND;										// Setting Return Code to file NOT_FOUND by default
	if (status == 0)														// Checking if file successfully removed
		returncode = RC_OK;													// Setting Return Code to OK if file successfully removed
	
	return returncode;														// Returning appropriate returncode
}

/*
	@brief Reads nth block from the file.
	@param SM_FileHandle *fHandle represents an open page file
	@param SM_PageHandle memPage pointer to an area in memory storing the data of a page
	@param int pageNum page number
	@return RC Return Code
*/
RC readBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
	RC returncode = RC_READ_NON_EXISTING_PAGE;								// Setting Return Code to READ_NON_EXISTING page by default

	if ((*fHandle).totalNumPages < pageNum)	                    			// Checking if pageNum is less than total no. of pages
		return returncode;

	
	fseek(fp, pageNum * PAGE_SIZE, SEEK_SET);                				// Setting pointer to current block
	RC read_size = fread(memPage, sizeof(char), PAGE_SIZE, fp);				// Read total number of bytes from block
	
	if (read_size != PAGE_SIZE) 						    				// Checking read_size matches PAGE_SIZE
		return RC_READ_NON_EXISTING_PAGE;

	(*fHandle).curPagePos = pageNum;										// Updating current page position to pageNum value
	return RC_OK;
}

/*
	@brief Return the current page position in a file
	@param SM_FileHandle *fHandle represents an open page file
	@return int current page position
*/
int getBlockPos(SM_FileHandle *fHandle) {
	return ((*fHandle).curPagePos);											// Get and return current page position	
}

/*
	@brief Read the first block in the file
	@param SM_FileHandle *fHandle represents an open page file
	@param SM_PageHandle memPage pointer to an area in memory that stores the page data
	@return Return Code
*/
RC readFirstBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
	int firstBlockPos = 0;													// Setting first block position

	RC returncode = RC_READ_NON_EXISTING_PAGE;								// Setting Return Code to READ_NON_EXISTING_PAGE by default
	if(readBlock(firstBlockPos, fHandle, memPage) == RC_OK)					// Check if readBlock function read the previous page successfully
		returncode = RC_OK;
	
	return returncode;														// Returning appropriate returncode
}

/*
	@brief Read the previous block in the file
	@param SM_FileHandle *fHandle represents an open page file
	@param SM_PageHandle memPage pointer to an area in memory that stores the page data
	@return Return Code
*/
RC readPreviousBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
	int prevBlockPos = getBlockPos(fHandle) - 1;							// Fetching previous block position

	RC returncode = RC_READ_NON_EXISTING_PAGE;								// Setting Return Code to READ_NON_EXISTING_PAGE by default
	if(readBlock(prevBlockPos, fHandle, memPage) == RC_OK)					// Check if readBlock function read the previous page successfully
		returncode = RC_OK;
	
	return returncode;														// Returning appropriate returncode
}

/*
	@brief Read the current block in the file
	@param SM_FileHandle *fHandle represents an open page file
	@param SM_PageHandle memPage pointer to an area in memory that stores the page data
	@return Return Code
*/
RC readCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
	int currentBlockPos = getBlockPos(fHandle);								// Fetching current block position

	RC returncode = RC_READ_NON_EXISTING_PAGE;								// Setting Return Code to READ_NON_EXISTING_PAGE by default
	if(readBlock(currentBlockPos, fHandle, memPage) == RC_OK)				// Check if readBlock function read the current page successfully
		returncode = RC_OK;
	
	return returncode;														// Returning appropriate returncode
}

/*
	@brief Read the next block in the file
	@param SM_FileHandle *fHandle represents an open page file
	@param SM_PageHandle memPage pointer to an area in memory that stores the page data
	@return Return Code
*/
RC readNextBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
	int nextBlockPos = getBlockPos(fHandle) + 1;							// Fetching last block position

	RC returncode = RC_READ_NON_EXISTING_PAGE;								// Setting Return Code to READ_NON_EXISTING_PAGE by default
	if(readBlock(nextBlockPos, fHandle, memPage) == RC_OK)					// Check if readBlock function read the next page successfully
		returncode = RC_OK;
	
	return returncode;														// Returning appropriate returncode
}

/*
	@brief Reading the final block of page-file
	@param SM_FileHandle *fHandle File handler representing an open page file
	@param SM_PageHandle memPage pointer to an area in memory that stores the page data
	@return Return Code
*/
RC readLastBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
	int lastBlockPos = (*fHandle).totalNumPages - 1;						// Fetching last block position
	
	RC returncode = RC_READ_NON_EXISTING_PAGE;								// Setting Return Code to READ_NON_EXISTING_PAGE by default
	if(readBlock(lastBlockPos, fHandle, memPage) == RC_OK) 					// Check if readBlock function read the last page successfully
		returncode = RC_OK;

	return returncode;														// Returning appropriate returncode
}

/*
	@brief Write a page to disk using an absolute position
	@param SM_FileHandle *fHandle represents an open page file
	@param SM_PageHandle memPage pointer to an area in memory that stores the page data
	@param int pageNum page number
	@return RC Return Code
*/
RC writeBlock(int pageNum, SM_FileHandle *fHandle, SM_PageHandle memPage) {
	if (pageNum < 0 || pageNum > (*fHandle).totalNumPages) 					// Checking if pageNum is valid
		return RC_WRITE_FAILED;

	if (fHandle == NULL)													// Checking if fHandle is initialized
		return RC_FILE_HANDLE_NOT_INIT;

	if (fp != NULL) { 														// Checking if file is available
		if (fseek(fp, (PAGE_SIZE * pageNum), SEEK_SET) == 0) {				// Checking if pointer is set to (PAGE_SIZE *pageNum) from beginning
				fwrite(memPage, sizeof(char), PAGE_SIZE, fp);				// Writing an array of PAGE_SIZE elements, each size of byte, to the stream pointed to by file.
																			// The data to be written is stored in the memory block pointed to memPage.
				(*fHandle).curPagePos = pageNum; 							// Setting current page position to pageNum 
				fseek(fp, 0, SEEK_END);
				(*fHandle).totalNumPages = ftell(fp) / PAGE_SIZE; 		   	// Incrementing totalNumPages by 1

				return RC_OK;												// Successful write operation on page.
		}
		return RC_WRITE_FAILED;										   		// Failure in writing block to current position.
	}
	return RC_FILE_NOT_FOUND;
}

/*
	@brief Write a page to disk using the current position
	@param SM_FileHandle *fHandle represents an open page file
	@param SM_PageHandle memPage pointer to an area in memory that stores the page data
	@return RC Return Code
*/
RC writeCurrentBlock(SM_FileHandle *fHandle, SM_PageHandle memPage) {
	int currentBlockPos = getBlockPos(fHandle);								// Fetching current block position

	RC returncode = RC_WRITE_FAILED;										// Setting returncode to WRITE_FAILED by default
	if (writeBlock(currentBlockPos, fHandle, memPage) == RC_OK)				// Checking if writeBlock at current position was successful
		returncode = RC_OK;													// Setting Return Code to OK since the block is now wrtten to the file
	
	return returncode;														// Returning appropriate returncode

}

/*
	@brief Appends a new empty block with '\0' bytes in the page file
	@param SM_FileHandle *fHandle File handler representing an open page file
	@return RC Return Code
*/
RC appendEmptyBlock(SM_FileHandle *fHandle) {
	if (fp == NULL)															// Checking if file exists. Returning if it does not.
		return RC_FILE_NOT_FOUND;
	
	RC returncode = RC_WRITE_FAILED;										// Setting returncode to WRITE_FAILED by default
	char *newblock;
	newblock = (char *) calloc(PAGE_SIZE, sizeof(char)); 					// Creating a new empty block
	
	fseek(fp, 0, SEEK_END);													// Moving pointer to end
	RC size = fwrite(newblock, 1, PAGE_SIZE, fp);							// Writing the empty block to the file

	if (size == PAGE_SIZE) {												// Checking if size of new block matches with PAGE_SIZE
		(*fHandle).totalNumPages = ftell(fp) / PAGE_SIZE; 					// Incrementing total no. of pages by 1 
		(*fHandle).curPagePos = (*fHandle).totalNumPages - 1; 				// Updating current page index by 1 less than the new totalNumPages
		returncode = RC_OK;													// Setting Return Code to OK since empty block is now appended to the file
	}
	free(newblock);															// Freeing the memory

	return returncode;														// Returning appropriate returncode
}

/*
	@brief Ensures if the capacity of page-file is equal to given number of pages
	@param int numberOfPages number of pages required
	@param SM_FileHandle *fHandle File handler representing an open page file
	@return RC Return Code
*/
RC ensureCapacity(int numberOfPages, SM_FileHandle *fHandle) {
	int currentCapacity = (*fHandle).totalNumPages;							// Fetching current capacity of pages in the file
	RC returncode = RC_WRITE_FAILED;										// Setting Return Code to WRITE_FAILED by default
	
	if (currentCapacity < numberOfPages) {									// Check if current capacity does not satisfy the requested number of pages
		int i, additionalPages = numberOfPages - currentCapacity;			// Number of additional pages required to ensure the capacity of file
		for(i=0;i<additionalPages;i++) {
			appendEmptyBlock(fHandle);										// Looping to append empty blocks to the file
		}
		returncode = RC_OK;													// Setting Return Code to OK since page file capacity is satisfied
	} else {																// Else capacity is satisfied
		returncode = RC_OK;													// Setting Return Code to OK if page file capacity is satisfied
	}

	return returncode;														// Returning appropriate returncode
}
