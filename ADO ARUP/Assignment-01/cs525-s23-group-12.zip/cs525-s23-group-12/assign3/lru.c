#include "strategies.h"

/*
	@brief Least-Recently-Used page replacement strategy 
	@param BM_BufferPool buffer pool
	@return RC Return Code
*/
RC pinPageLRU(BM_BufferPool *const bp, BM_PageHandle *const pageHandle, const PageNumber pNo)
{
	SM_FileHandle fh;
	BM_BufferPool_Mgmt *bp_mgmt = (*bp).mgmtData;
	PageFrame *frame = (*bp_mgmt).head;

	openPageFile((char*) (*bp).pageFile,&fh);

	if((*frame).pageNum == pNo)
	{
		(*pageHandle).pageNum = pNo;													// Update page and buffer frame attributes
		(*pageHandle).data = (*frame).data;

		(*frame).pageNum = pNo;
		(*frame).fixCnt++;

		(*bp_mgmt).tail = (*(*bp_mgmt).head).next;										// For replacement, point to head and tail
		(*bp_mgmt).head = frame;
		return RC_OK;
	}

	frame = (*frame).next;

	while(frame != (*bp_mgmt).head)														// Check if page exists in the buffer pool
	{
		if((*frame).pageNum == pNo)
		{
			(*pageHandle).pageNum = pNo;													// Update page and buffer frame attributes
			(*pageHandle).data = (*frame).data;

			(*frame).pageNum = pNo;
			(*frame).fixCnt++;

			(*bp_mgmt).tail = (*(*bp_mgmt).head).next;										// For replacement, point to head and tail
			(*bp_mgmt).head = frame;
			return RC_OK;
		}

		frame = (*frame).next;

	}

	if((*bp_mgmt).occupiedCnt < (*bp).numPages)											// Check if there are empty spaces in buffer pool,
	{																						// And first fill those frames
		frame = (*bp_mgmt).head;
		(*frame).pageNum = pNo;

		if((*frame).next != (*bp_mgmt).head)
		{
			(*bp_mgmt).head = (*frame).next;
		}
		(*frame).fixCnt++;																// Increment fixCount
		(*bp_mgmt).occupiedCnt++;															// Increment occupiedCount
	}
	else
	{
		frame = (*bp_mgmt).tail;															// Use LRU to replace pages from frame
		do
		{
			if((*frame).fixCnt != 0)														// Check if page is in use and move to next page for replacement
			{
				frame = (*frame).next;
			}
			else
			{
				if((*frame).dirtyFlg == 1)													// Check if dirty flag is set before replacing
				{																			// Write back the content to the disk
					ensureCapacity((*frame).pageNum, &fh);
					if(writeBlock((*frame).pageNum, &fh, (*frame).data) != RC_OK)
					{
						closePageFile(&fh);
						return RC_WRITE_FAILED;
					}
					(*bp_mgmt).numWrite++;													// Increment number of writes
				}

				if((*bp_mgmt).tail != (*bp_mgmt).head)										// Find the LRU page and replace it
				{
					(*frame).pageNum = pNo;
					(*frame).fixCnt++;
					(*bp_mgmt).tail = frame;
					(*bp_mgmt).tail = (*frame).next;
					break;
				}
				else
				{
					frame = (*frame).next;
					(*frame).pageNum = pNo;
					(*frame).fixCnt++;
					(*bp_mgmt).tail = frame;
					(*bp_mgmt).head = frame;
					(*bp_mgmt).tail = (*frame).prev;
					break;
				}
			}
		} while(frame != (*bp_mgmt).tail);
	}

	ensureCapacity((pNo + 1), &fh);
	
	if(readBlock(pNo, &fh, (*frame).data) != RC_OK)
	{
		return RC_READ_NON_EXISTING_PAGE;
	}
	
	(*bp_mgmt).numRead++;

	(*pageHandle).pageNum = pNo;															// Update the page frame and its data
	(*pageHandle).data = (*frame).data;

	closePageFile(&fh);																		// Close pagefile

	return RC_OK;
}
