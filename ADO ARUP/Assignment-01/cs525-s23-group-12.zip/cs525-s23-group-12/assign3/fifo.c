#include "strategies.h"

/*
	@brief First-In-First-Out page replacement strategy 
	@param BM_BufferPool buffer pool
	@return RC Return Code
*/
RC pinPageFIFO(BM_BufferPool *const bp, BM_PageHandle *const pageHandle, const PageNumber pNo)
{
	SM_FileHandle fh;
	BM_BufferPool_Mgmt *bp_mgmt = (*bp).mgmtData;
	PageFrame *frame = (*bp_mgmt).head;

	openPageFile((char*) (*bp).pageFile,&fh);

	if((*frame).pageNum == pNo)															// Add the data in the page and increment fixCount
	{
		(*pageHandle).pageNum = pNo;
		(*pageHandle).data = (*frame).data;

		(*frame).pageNum = pNo;
		(*frame).fixCnt++;
		return RC_OK;
	}

	frame = (*frame).next;

	while(frame!= (*bp_mgmt).head)															// Check if page exists in the buffer pool
	{
		if((*frame).pageNum == pNo)															// Add the data in the page and increment fixCount
		{
			(*pageHandle).pageNum = pNo;
			(*pageHandle).data = (*frame).data;

			(*frame).pageNum = pNo;
			(*frame).fixCnt++;
			return RC_OK;
		}

		frame = (*frame).next;

	}

	if((*bp_mgmt).occupiedCnt < (*bp).numPages)											// Check if there are empty spaces in buffer pool,
	{																						// And first fill those frames
		frame = (*bp_mgmt).head;
		(*frame).pageNum = pNo;

		if((*frame).next != (*bp_mgmt).head)												// Move to next empty space by moving the header
		{
			(*bp_mgmt).head = (*frame).next;
		}
		(*frame).fixCnt++;
		(*bp_mgmt).occupiedCnt++;															// Increment occupiedCount
	}
	else																					// Use FIFO strategy to replace pages
	{
		frame = (*bp_mgmt).tail;															// Replace pages from frame
		do
		{
			if((*frame).fixCnt != 0)														// Check if the page is in use
			{																				// Move to next frame where fixCount is 0, and replace the page
				frame = (*frame).next;
			}
			else
			{
				if((*frame).dirtyFlg == 1)													// Check if dirty flag is set before replacing
				{																			// Write back the content to the disk
					ensureCapacity((*frame).pageNum, &fh);
					if(writeBlock((*frame).pageNum, &fh, (*frame).data) != RC_OK)
					{
						closePageFile(&fh);
						return RC_WRITE_FAILED;
					}
					(*bp_mgmt).numWrite++;
				}

				(*frame).pageNum = pNo;														// Update page and buffer pool attributes
				(*frame).fixCnt++;
				(*bp_mgmt).tail = (*frame).next;
				(*bp_mgmt).head = frame;
				break;
			}
		} while(frame != (*bp_mgmt).head);
	}

	ensureCapacity((pNo + 1), &fh);															// Ensure if the pageFile has the required page capacity

	if(readBlock(pNo, &fh, (*frame).data) != RC_OK)											// Read the block
	{
		closePageFile(&fh);
		return RC_READ_NON_EXISTING_PAGE;
	}

	(*bp_mgmt).numRead++;																	// Increment number of read

	(*pageHandle).pageNum = pNo;															// Update attributes and add the data in page
	(*pageHandle).data = (*frame).data;

	closePageFile(&fh);																		// Close pageFile

	return RC_OK;
}
