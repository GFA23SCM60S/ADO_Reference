#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "strategies.h"
/*
@brief Create a Buffer Pool with specified number of Page Frames
@param BM_BufferPool_Mgmt *bbmg pointer to an area in buffer manager 
*/
void createPageFrame(BM_BufferPool_Mgmt *bbmg)
{
	
	PageFrame *frame = (PageFrame *) malloc(sizeof(PageFrame));//Frame creation and memory allocation to it
	(*frame).fixCnt = 0;									   //Initialized count to zero.(i.e. initially page is not access by any user)
	(*frame).frameNum = 0;									   //Initialize frame count to zero.
	(*frame).pageNum = -1;									   //Initialize page count to -1
	(*frame).dirtyFlg = 0;									   //Initialize flag to FALSE
	(*frame).data = calloc(PAGE_SIZE,sizeof(char*));           //Memory allocation for page into pageFrame
	(*bbmg).head = (*bbmg).start;							   //Initialise the pointers and point start to head 

	if((*bbmg).head != NULL)								   //Find position to append new node & add node
	{
		(*bbmg).tail->next = frame;
		(*frame).prev = (*bbmg).tail;
		(*bbmg).tail = (*bbmg).tail->next;
		
	}
	else													  //Assign first frame to head and frame next to tail		
	{
		(*bbmg).head = frame;
		(*bbmg).tail = frame;
		(*bbmg).start = frame;
	}

	(*(*bbmg).tail).next = (*bbmg).head;                        // Initialize tail's next to head
	(*(*bbmg).head).prev = (*bbmg).tail;						// Initialize head's previous to tail
}


/*
 @brief BufferPool initialization
 @param BM_BufferPool *const bm: used to store the mgmtData
 @param const char *const pageFileName: page file name for which pages are to be cached
 @param const int numPages: Number of frames in the buffer Pool
 @param ReplacementStrategy strategy: Page Replacement Strategy to be used
 @param void *stratData: parameters required for page replacement strategy
 @return returncode
 */
RC initBufferPool(BM_BufferPool *const bm, const char *const pageFileName, const int numPages, ReplacementStrategy strategy,void *stratData)
{
	BM_BufferPool_Mgmt *pool = (BM_BufferPool_Mgmt*)malloc(sizeof(BM_BufferPool_Mgmt));   //Memory allocation for the Buffer Pool Management Data
	SM_FileHandle fh;																	  //File handler for Storage manager 
	int i;
	openPageFile((char*) pageFileName,&fh);												  //Open the page file for caching it's pages
	
	i=0;
	while(i<numPages) { 															  //Create the frames for buffer pool
		createPageFrame(pool);
		i++;
	}

	(*bm).numPages = numPages;            //Number of page frames
	(*bm).pageFile = (char*) pageFileName;//Name of the page file associated with the buffer pool
	(*bm).strategy = strategy;			  //Page replacement strategy
	(*bm).mgmtData = pool;				  //Pointer to bookkeeping data
	(*pool).numRead = 0;				  //Pages read from buffer pool set 0
	(*pool).numWrite = 0;				  //Pages write from buffer pool set 0
	(*pool).tail = (*pool).head;          //Initialize tail and head
	(*pool).stratData = stratData;        //Initialize startData in buffer pool
	(*pool).occupiedCnt = 0;			  //Occupied count set to 0

	closePageFile(&fh);					  //close the page file

	return RC_OK;
}

/*
 @brief Destroy the buffer pool (shutdown a buffer pool and free up all associated resources)
 @param BM_BufferPool *const bm: pointer to buffer pool which need to shutdown
 @return returncode
 */
RC shutdownBufferPool(BM_BufferPool *const bm)
{
	
	BM_BufferPool_Mgmt *bb_mg;            
	bb_mg = (*bm).mgmtData;              //pointer to buffer pool
	PageFrame *Frame = (*bb_mg).head;
	forceFlushPool(bm);					 //writes all the dirtyPages back again, before destroying

	while(Frame!=(*bb_mg).head)		 //Free all the page data from the frame
	{
		free((*Frame).data);             //Free page data from each frame
		Frame= (*Frame).next;
	}

	(*bb_mg).start = NULL;				//Set start to null
	(*bb_mg).head = NULL;				//Set head to null
	(*bb_mg).tail = NULL;				//Set tail to null

	free(Frame);                        //Free entire frame
	free(bb_mg);						//free the bufferPool

	(*bm).numPages = 0;
	(*bm).mgmtData = NULL;
	(*bm).pageFile = NULL;

	return RC_OK;
}

/*
 @brief mark the page as dirty
 @param BM_BufferPool *const bm: stores information about a buffer poo
 @param BM_PageHandle *const page:stores information about a page
 @return return code
 */
RC markDirty (BM_BufferPool *const bm, BM_PageHandle *const page)
{
	int returncode = RC_OK;
	BM_BufferPool_Mgmt *bbmg;
	bbmg = (*bm).mgmtData;
	PageFrame *frame = (*bbmg).head;
	if((*page).pageNum == (*frame).pageNum) //check the pageNum is same as the page to be marked dirty
	{
		(*frame).dirtyFlg = 1;              //make page is dirty
		returncode = RC_OK;
	}
	frame=(*frame).next;
	while(frame!=(*bbmg).head)
	{
		if((*page).pageNum == (*frame).pageNum) //check the pageNum is same as the page to be marked dirty
		{
			(*frame).dirtyFlg = 1;              //make page is dirty
 			returncode = RC_OK;
		}
		frame=(*frame).next;
	}

	return returncode;
}

/*
 * @brief All the pages to the disk whose dirtyBit is set
   @param BM_BufferPool *const bm:pointer to buffer pool
   @return returncode
 */
RC forceFlushPool(BM_BufferPool *const bm)
{
	int returncode = RC_FILE_NOT_FOUND;
	BM_BufferPool_Mgmt *bp_mgmt;                     //pointer to buffer pool
	bp_mgmt = (*bm).mgmtData;                        
	PageFrame *Frame = (*bp_mgmt).head;              //Set to buffer manager head.

	SM_FileHandle fh;

	if (openPageFile ((char *)(bm->pageFile), &fh) != RC_OK)//open file 
	{
		returncode =  RC_FILE_NOT_FOUND;							//return error code if file not found
	}
	else
	{
		do
		{
			if((*Frame).dirtyFlg == 1 && (*Frame).fixCnt == 0)              //check dirtyFlg is set and fix count is 0
			{
				
				if(writeBlock((*Frame).pageNum, &fh, (*Frame).data) != RC_OK)//write the pages to disk
				{
					returncode = RC_WRITE_FAILED;                                  //return error code if write failed
					closePageFile(&fh);
				}
				(*bp_mgmt).numWrite++;                                      //Increment write page count 
				(*Frame).dirtyFlg = 0;										//Change the dirtyFlag to 0
			}
			Frame = (*Frame).next;											//move to next frame
		}while(Frame != (*bp_mgmt).head);
		
		closePageFile(&fh);													//close the page file
		returncode = RC_OK;
	}
	return returncode;
}

/*
 @brief : force a page back to disk
 @param BM_BufferPool *const bm: stores information about a buffer poo
 @param BM_PageHandle *const page:stores information about a page
 @return return code
 */
RC forcePage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
	int returncode = RC_FILE_NOT_FOUND;
	BM_BufferPool_Mgmt *bbmg;
	bbmg = bm->mgmtData;

	PageFrame *Frame = (*bbmg).head;
	SM_FileHandle fh;

	if (openPageFile ((char *)((*bm).pageFile), &fh) != RC_OK)
	{
		returncode = RC_FILE_NOT_FOUND;
	}
	else
	{
		if((*Frame).pageNum == (*page).pageNum && (*Frame).dirtyFlg == 1) //Find the page that needs to be written back & its dirty flag is 1
		{
			if(writeBlock((*Frame).pageNum, &fh, (*Frame).data) != RC_OK)
			{
				closePageFile(&fh);
				return RC_WRITE_FAILED;
			}
			(*bbmg).numWrite++;	//increment the num of writes performed
			(*Frame).dirtyFlg = 0;	//unmark its dirty bit
		}
		Frame= (*Frame).next;
		while(Frame!=(*bbmg).head)
		{
			if((*Frame).pageNum == (*page).pageNum && (*Frame).dirtyFlg == 1) //Find the page that needs to be written back & its dirty flag is 1
			{
				if(writeBlock((*Frame).pageNum, &fh, (*Frame).data) != RC_OK)
				{
					closePageFile(&fh);
					return RC_WRITE_FAILED;
				}
				(*bbmg).numWrite++;	//increment the num of writes performed
				(*Frame).dirtyFlg = 0;	//unmark its dirty bit
				break;
			}
			Frame= (*Frame).next;
		}

		closePageFile(&fh);
		returncode = RC_OK;
	}
	return returncode;
}

/*
	@brief Add a page onto the buffer pool. 
			Page is first inserted in a pageFrame and then added in the buffer pool.
			This method is called as "PINNING" a page.
	@param BM_BufferPool stores info about the buffer pool
	@param BM_PageHandle stores information about a page
	@param PageNumber integer that defines the page number
	@return RC Return Code
 */
RC pinPage (BM_BufferPool *const bm, BM_PageHandle *const page,const PageNumber pageNum)
{
	switch((*bm).strategy)
	{
	case RS_FIFO:
		pinPageFIFO(bm, page, pageNum);
		break;

	case RS_LRU:
		pinPageLRU(bm,page,pageNum);
		break;

	case RS_CLOCK:
	case RS_LFU:
	case RS_LRU_K:
		break;

	default:
		return RC_REPLACEMENTSTRATEGY_NOT_FOUND;
	}
	return RC_OK;
}

/*
 @brief : unpin page
 @param BM_BufferPool *const bm: stores information about a buffer poo
 @param BM_PageHandle *const page:stores information about a page
 @return return code
 */
RC unpinPage (BM_BufferPool *const bm, BM_PageHandle *const page)
{
	int returncode = RC_OK;
	BM_BufferPool_Mgmt *bbmg;
	bbmg = (*bm).mgmtData;
	PageFrame *frame = (*bbmg).head;

	if((*page).pageNum == (*frame).pageNum)
	{
		
		(*frame).fixCnt--;
		returncode = RC_OK;
	}
	frame = (*frame).next;
	while(frame!= (*bbmg).head)
	{
		if((*page).pageNum == (*frame).pageNum)
		{
			
			(*frame).fixCnt--;
			returncode = RC_OK;
		}
		frame = (*frame).next;
	}

	return returncode;
}

/*
	@brief Fetch array of PageNumbers (of size numPages) where ith element
			is the number of the page stored in the ith page frame.
			An empty page frame is represented using the constant NO_PAGE.
	@param BM_BufferPool buffer pool
	@return frame Contents
 */
PageNumber *getFrameContents (BM_BufferPool *const bm)
{
	BM_BufferPool_Mgmt *bbmg;
	bbmg = (*bm).mgmtData;
	(*bbmg).frameContent = (PageNumber*)malloc(sizeof(PageNumber)*(*bm).numPages);

	PageFrame *frame = (*bbmg).start;
	PageNumber* frameContents = (*bbmg).frameContent;

	int i;
	int page_count = (*bm).numPages;

	if(frameContents != NULL)
	{
		i=0;
		while(i<page_count)
		{
			frameContents[i] = (*frame).pageNum;
			frame = (*frame).next;
			i++;
		}
	}
	

	return frameContents;
}

/*
	@brief Get array of bools (of size numPages) where ith element
			is TRUE if the page stored in the ith page frame is dirty.
			Empty page frames are considered as clean.
	@param BM_BufferPool buffer pool
	@return dirty bits
 */
bool *getDirtyFlags (BM_BufferPool *const bm)
{
	BM_BufferPool_Mgmt *bbmg;
	bbmg = (*bm).mgmtData;
	(*bbmg).dirtyBit = (bool*)malloc(sizeof(bool)*(*bm).numPages);

	PageFrame *frame = (*bbmg).start;
	bool* dirtyBit = (*bbmg).dirtyBit;

	int i,page_count = (*bm).numPages;

	if(dirtyBit != NULL)
	{
		i=0;
		while(i<page_count)
		{
			dirtyBit[i] = (*frame).dirtyFlg;
			frame = (*frame).next;
			i++;
		}
	}
	return dirtyBit;
}

/*
	@brief Fetch array of integers (of size numPages) where ith element 
			is the fix count of the page stored in the ith page frame.
	@param BM_BufferPool buffer pool
	@return fixCount for the page.
 */
int *getFixCounts (BM_BufferPool *const bm)
{
	BM_BufferPool_Mgmt *bbmg;
	bbmg = (*bm).mgmtData;
	(*bbmg).fixCnt = (int*)malloc(sizeof(int)*(*bm).numPages);

	PageFrame *frame = (*bbmg).start;
	int* fixCnt = (*bbmg).fixCnt;

	int i,page_count = (*bm).numPages;

	if(fixCnt != NULL)
	{
		i=0;
		while(i< page_count)
		{
			fixCnt[i] = (*frame).fixCnt;
			frame = (*frame).next;
			i++;
		}
	}

	return fixCnt;
}

/*
	@brief Get total number of readBlock operations
	@param BM_BufferPool buffer pool
	@return number of pages read from buffer pool
 */
int getNumReadIO (BM_BufferPool *const bm)
{
	int result = (*(BM_BufferPool_Mgmt*)bm->mgmtData).numRead;
	return result;
}

/*
	@brief Fetch total number of writeBlock operations
	@param BM_BufferPool buffer pool
	@return number of pages written in buffer pool
 */
int getNumWriteIO (BM_BufferPool *const bm)
{
	int result = (*(BM_BufferPool_Mgmt*)bm->mgmtData).numWrite;
	return result;
}
