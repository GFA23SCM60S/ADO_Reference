#include "stdio.h"
#include "stdlib.h"
#include "string.h"

#include "buffer_mgr.h"
#include "storage_mgr.h"

typedef struct PageFrame
{
	int frameNum;						// pageframe number
	int pageNum;						// Page Number of the page in the frame
	int dirtyFlg;						// Dirty flag to check if page is modified
	int fixCnt;		    				// Fix count to check if other users are using the page
	char *data;							// Data that exists in the page
	struct PageFrame *next, *prev;		// Next Node and Previous Node of the Doubly linked List (each node is a frame that points to other frames)
} PageFrame;

typedef struct BM_BufferPool_Mgmt		// Buffer Pool struct that stores management info
{
	int occupiedCnt;					// Count of occupied frames in the pool
	void *stratData;					// Pass parameters for different page replacement strategies
	PageFrame *head,*tail,*start;		// Track nodes in doubly linked list
	PageNumber *frameContent;			// Store the statistics of page number in the page frame
	int *fixCnt;						// Store the statistics of fix counts for a page
	bool *dirtyBit;						// Store the statistics of dirty bits for modified page
	int numRead;						// Pages read from the buffer pool
	int numWrite;						// Pages written in the buffer pool
} BM_BufferPool_Mgmt;

RC pinPageLRU(BM_BufferPool *const bp, BM_PageHandle *const pageHandle, const PageNumber pNo);
RC pinPageFIFO(BM_BufferPool *const bp, BM_PageHandle *const pageHandle, const PageNumber pNo);
